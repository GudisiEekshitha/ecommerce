package com.surya.service;

import com.surya.entity.UserInfo;

public interface UserInfoService
{
    public UserInfo saveUser(UserInfo userInfo);
}
